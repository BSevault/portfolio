-- Donnez la liste du matériel en état :  disponible

SELECT * FROM MATERIEL WHERE DISPO = 1;