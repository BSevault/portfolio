-- Donnez la liste de tous le matériel

SELECT * FROM MATERIEL;